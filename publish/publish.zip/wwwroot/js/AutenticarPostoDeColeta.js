/*(function() {
var modal = document.getElementById('dialog');
var cancel = document.getElementById('cancel');

    cancel.addEventListener('click', function() {
        modal.close();
      });
    });*/